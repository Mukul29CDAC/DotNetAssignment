﻿namespace Day1Lab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee e1 = new Employee();
            e1.setBasic = 25000;
            e1.setName = "Mukul";
            e1.setEmpNo = 1;
            e1.setDeptNO = 10;
            Console.WriteLine(e1.setName + " " + e1.setEmpNo +" " + e1.setDeptNO + " " + e1.setBasic);
            Console.WriteLine(e1.GetNetSalary());
        }

        public class Employee
        {
            private string Name;
            private int EmpNo;
            private decimal basic;
            private short DeptNo;

            public decimal setBasic
            {
                set
                {
                    if(value > 100 && value < 100000)
                    {
                        basic = value;
                    }
                  
                }
                get{
                    return basic;
                }

            }

            public string setName
            {
                set
                {
                    if(!value.Contains(" "))
                    {
                        Name = value;
                    }
                   
                   
                }
                get
                {
                    return Name;
                }

            }

            public int setEmpNo
            {
                set
                {
                    if(value > 0)
                    {
                        EmpNo = value;
                    }
                    else
                    {
                        Console.WriteLine("0 Emp No");
                    }
                   
                }
                get
                {
                    return EmpNo;
                }

            }

            public short setDeptNO
            {
                set
                {
                    if (value > 0)
                    {
                        DeptNo = value;
                    }
                    else
                    {
                        Console.WriteLine("0 Dept No");
                    }

                }
                get
                {
                    return DeptNo;
                }

            }

            public decimal GetNetSalary()
            {
                return setBasic * 10;
            }


        }
    }
}
