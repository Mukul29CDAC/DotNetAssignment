﻿namespace day2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee e1 = new Employee("Mukul",25000,10);
            Employee e2 = new Employee("Gaurav", 25000, 11);
            Employee e3 = new Employee("Aditya", 25000, 12);
            Employee e4 = new Employee("Ishwar", 25000, 13);
            Employee e5 = new Employee("Atharav", 25000, 14);
            Console.WriteLine(e1.ToString());
            Console.WriteLine(e2.ToString());
            Console.WriteLine(e3.ToString());
            Console.WriteLine(e4.ToString());
            Console.WriteLine(e5.ToString());

        }

        public class Employee
        {

            private static int count = 1;
            private string Name;
            private int EmpNo;
            private decimal Basic;
            private short DeptNo;

            public Employee(string Name = "", decimal Basic = 0,short DeptNo= 0)
            {
                setName = Name;
                this.EmpNo = count++;
                setBasic = Basic;
                setDeptNo = DeptNo;
            }

            public decimal setBasic
            {
                set
                {
                    if (value > 100 && value < 100000)
                    {
                        Basic = value;
                    }

                }
                get
                {
                    return Basic;
                }

            }

            public string setName
            {
                set
                {
                    if (!value.Contains(" "))
                    {
                        Name = value;
                    }


                }
                get
                {
                    return Name;
                }

            }

            public int setEmpNo
            {
              
                get
                {
                    return EmpNo;
                }

            }

            public short setDeptNo
            {
                set
                {
                    if (value > 0)
                    {
                        DeptNo = value;
                    }
                    else
                    {
                        Console.WriteLine("0 Dept No");
                    }

                }
                get
                {
                    return DeptNo;
                }

            }

            public decimal GetNetSalary()
            {
                return Basic * 10;
            }

            public override string ToString()
            {
                return Name + " "+ EmpNo + " " + Basic + " " + DeptNo;
            }


        }
    }
}
