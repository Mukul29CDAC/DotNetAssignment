﻿namespace Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            List<Employee> employees = new List<Employee>();
            
            employees.Add(new Employee("Mukul",5200));
            employees.Add(new Employee("Abhi", 500));
            employees.Add(new Employee("Anni", 15200));
            employees.Add(new Employee("Archit", 5205));

            //Console.WriteLine(Employee.GetHighestSalary(employees));
            //Console.WriteLine(Employee.FindById(2,employees));

            Employee[] empArray = employees.ToArray();
            foreach(Employee emp in empArray)
            {
                //Console.WriteLine(emp);
            }

            List<Employee> empList = empArray.ToList();
            foreach (Employee emp in empList)
            {
                Console.WriteLine(emp);
            }

        }

        public class Employee
        {
            private static int count = 1;
            public int empNo;
            private  string name;
            private int salary;

            public Employee(string name,int salary)
            {
                this.empNo = count++;
                this.Name = name;
                this.Salary = salary;
            }

            public string Name
            {
                get
                {
                    return name;

                }
                set
                {
                    name = value;
                }
            }

            public int Salary
            {
                get
                {
                    return salary;

                }
                set
                {
                    salary = value;
                }
            }

            public static Employee GetHighestSalary(List<Employee> emp)
            {
               if(emp.Count > 0)
                {
                  return (Employee)emp.OrderByDescending(e => e.Salary).First();
                }

                return null;    
            }


            public static Employee FindById(int id,List<Employee> emp)
            {
                if (emp.Count > 0)
                {
                    return (Employee)emp.Find(e => e.empNo == id);
                }

                return null;
            }

            public override string? ToString()
            {
                return $"Empno {empNo} Name {Name},Salary {Salary}";
            }
        }
    }
}
