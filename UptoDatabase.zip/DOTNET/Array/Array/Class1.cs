﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    internal class MainClass
    {
        static void Main()
        {
         
            Employee[] employees = { new Employee("Mukul", 88200) ,new Employee("Anni", 6500), new Employee("Ashu Biwi", 4500) };
            
            Console.WriteLine(Employee.FindEmployee(3,employees));
            Console.WriteLine(Employee.GetHighestSalary( employees));

        }
    }

        internal class Employee
    {
        private static int count = 1;
        private int empNo;
        private string name;
        private int salary;

        public Employee(string name, int salary)
        {
            this.empNo = count++;
            this.Name = name;
            this.Salary = salary;

        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public int Salary
        {
            get
            {
                return salary;
            }
            set
            {
                salary = value;
            }
        }
        public int EmpNo
        {
            get
            {
                return empNo;
            }

        }

        public static Employee FindEmployee(int empNo, Employee[] emp)
        {
            foreach(Employee e in emp)
            {
                if (e.EmpNo == empNo)
                {
                    return e;
                }
            }
            return null;
          
        }

        public static Employee GetHighestSalary(Employee[] emp)
        {
            int l = 0;
            int idx = -1;
            for(int i = 0;i < emp.Length;i++)
            {
                if (emp[i].Salary > l)
                {
                    l = emp[i].salary;
                    idx = i;
                }
                
            }
            return emp[idx] ;

        }

        public override string ToString()
        {
            return $"EmpNo {EmpNo}, Name {Name}, Salary {Salary}"; 
        }
    }

}
