﻿using System.Xml.Linq;

namespace Array1
{
    internal class Program
    {
        internal class Student
        {
            private static int idCounter;
            public int Id { get; set; }
            public string Name { get; set; }
            public float Marks { get; set; }

            static Student() { idCounter = 1; }
            public Student(string name = "Andy", float marks = 30F)
            {
                Id = idCounter++;
                Name = name;
                Marks = marks;
            }

            public override string ToString() { return $"STD{Id}: Name: {Name}, Marks:{Marks}"; }
        }

        internal class Batch
        {
            private static int idCounter;
            public int Id { get; set; }
            Student[] students;
            static Batch() { idCounter = 1; }
            public Batch(Student[] students)
            {
                Id = idCounter++;
                this.students = students;
            }
        }

        static void Main1(string[] args)
        {
            Console.Write("Enter number of batches : ");
            int numberOfBatchs = 4;

            Student[] batch1Students = { new Student(), new Student(), new Student() };
            Student[] batch2Students = { new Student(), new Student(), new Student() };
            Student[] batch3Students = { new Student(), new Student(), new Student() };
            Student[] batch4Students = { new Student(), new Student(), new Student() };

            Batch batch1 = new Batch(batch1Students);
            Batch batch2 = new Batch(batch2Students);
            Batch batch3 = new Batch(batch3Students);
            Batch batch4 = new Batch(batch4Students);

        }


    }
}
