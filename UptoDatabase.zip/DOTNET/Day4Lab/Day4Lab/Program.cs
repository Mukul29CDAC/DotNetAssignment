﻿using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace Day4Lab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //WriteFileWithByte();
            //ReadFileWithByte();
            //WriteFileWithFormatter();
            //ReadFileWithFormatter();
            //WriteFileWithBinary();
            //ReadFileWithBinary();
            //FileSerialise();
            ReadSerialise();
        }

        static void WriteFileWithByte()
        {
            string s = "Hello Mukul";
            byte[] arr = Encoding.Default.GetBytes(s);

            FileStream stream = File.Open("C:\\Users\\dac\\Desktop\\Demo.txt", FileMode.Create);

            stream.Write(arr, 0, arr.Length);

            stream.Close();
        }

        static void ReadFileWithByte() {
           
            FileStream stream = File.Open("C:\\Users\\dac\\Desktop\\Demo.txt" , FileMode.Open);

            byte[] arr = new byte[stream.Length];

            stream.Read(arr, 0, arr.Length);

            string s = Encoding.Default.GetString(arr);

            Console.WriteLine(s);
            stream.Close();

        }

        static void WriteFileWithFormatter()
        {

            StreamWriter writer = File.CreateText("C:\\Users\\dac\\Desktop\\Demo.txt");
            writer.WriteLine(writer.ToString());

            writer.Write("Hello Abhishek");
            writer.Close();
        }

        static void ReadFileWithFormatter()
        {
            string s;

            StreamReader reader = File.OpenText("C:\\Users\\dac\\Desktop\\Demo.txt");
            
            while((s = reader.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }

            reader.Close();
        }

        static void WriteFileWithBinary()
        {
            string s = "Hello";
            int i = 100;
            bool b = false; 

            FileInfo f = new FileInfo("C:\\Users\\dac\\Desktop\\Demo.txt");
            BinaryWriter bw = new BinaryWriter(f.OpenWrite());

            bw.Write(s);
            bw.Write(i);
            bw.Write(b);

            bw.Close();
        }

        static void ReadFileWithBinary()
        {
            string s;
            int i;
            bool b;

            FileInfo f = new FileInfo("C:\\Users\\dac\\Desktop\\Demo.txt");
            BinaryReader br = new BinaryReader(f.OpenRead());

            s = br.ReadString();
            i = br.ReadInt32();
            b = br.ReadBoolean();

            Console.WriteLine(s + " " + i + " " + b);

            br.Close();
        }

        [Serializable]
        public class FileHandling
        {
            private int i;
            private string s;
            private decimal d;

            public FileHandling()
            {

            }

            public int I
            {
                get;
                set;
            }

            public string S
            {
                get;
                set;
            }
            
            public decimal D
            {
                get;
                set;
            }
        }

        static void FileSerialise()
        {
            FileHandling obj = new FileHandling();

            obj.I = 10;
            obj.S = "Hello";
            obj.D = 12;

            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(FileHandling));

            Stream s = new FileStream("C:\\Users\\dac\\Desktop\\Demo.json",FileMode.Create);
            
            js.WriteObject(s, obj);

            s.Close();
            

        }

        static void ReadSerialise()
        {
            FileHandling obj;

            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(FileHandling));

            Stream s = new FileStream("C:\\Users\\dac\\Desktop\\Demo.json", FileMode.Create);

            //js.ReadObject(s);

            Console.WriteLine(js.ReadObject(s));

            s.Close();


        }



    }
}
