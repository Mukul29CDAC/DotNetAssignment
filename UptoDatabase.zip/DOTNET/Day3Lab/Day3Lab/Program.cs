﻿namespace Day3Lab
{
    internal  class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Class1 class1 = new Class1();
            Console.WriteLine(class1.B(10));
            Console.WriteLine(class1.c("garg"));

            List<int> i = new List<int>();
            //for(int j = 0; j < 5; j++)
            //{
            //    i.Add(j);
            //}

            var obj = from a in i where a > 2 select a;
            //foreach(int x in obj)
            //{
            //    Console.WriteLine(x);
            //}

            List<Department> dlist = new List<Department>();
            dlist.Add(new Department(10, "Tech"));
            dlist.Add(new Department(20, "Test"));
            dlist.Add(new Department(30, "Support"));
            dlist.Add(new Department(40, "CEO"));

            List<Employee> elist = new List<Employee>();
            elist.Add(new Employee(1, "Mukul",10));
            elist.Add(new Employee(2, "Mul",12));
            elist.Add(new Employee(3, "kul",20));
            elist.Add(new Employee(4, "Muk",22));

            var j = from emp in elist join dept in dlist on emp.dId equals dept.dId where dept.dId > 10  select new { emp.name, dept.dName };
            ;

            var xyz = elist.Select(x => x).Where(y => y.dId > 12).ToList();
  

            foreach(var x in xyz)
            {
                Console.WriteLine(x);
            }

        }

    }

    internal partial class Class1
    {
        private int a = 10;
        private string s = "mukul";

        public Boolean B(int b)
        {
            return a.Add(b);
        }

        public string c(string b)
        {
            return s.str(b);
        }


    } 

    internal class Employee
    {
        public int id;
        public string name;
        public int dId;

        public Employee(int id,string name , int dId)
        {
            this.id = id;
            this.name = name;
            this.dId = dId;
        }

        public override string ToString()
        {
            return $"Name {name} ,id {id}";
        }
    }

    internal class Department
    {
        public int dId;
        public string dName;

        public Department(int id, string name)
        {
            this.dId = id;
            this.dName = name;
        }

        public override string ToString()
        {
            return $"Name {dName} ,id {dId}";
        }
    }

    internal static class Class2
    {

        public static Boolean Add(this int x, int y)
        { return x + y >10; }

        public static string str(this string x, string y)
        { return x + y ; }

    }
}
