﻿namespace tryItOnceAgain
{

    class Person
    {
        private String name;
        private String age;
        public String Name{
            get
            {
                return name;
            }
            set
            {
                if (name.Equals("Tejas"))
                {
                    Console.WriteLine("Bhag bsdk");
                }
                else
                {
                    name = value;
                }
            }

        } 
    }


    class Program
    {
        static void Main(String[] args) {
            String name;
            Person p = new Person();
            Console.WriteLine("Enter name : ");
            name = Console.ReadLine();
            p.Name = name;
            Console.WriteLine(p.Name);
        
        }
    }

}