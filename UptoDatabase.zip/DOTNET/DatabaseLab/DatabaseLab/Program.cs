﻿using Microsoft.Data.SqlClient;

namespace DatabaseLab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=(localdb)\\ProjectModels;Initial Catalog=Batch1_Mukul;Integrated Security=True;MultipleActiveResultSets=true;";

            //Connect(con);
            //InsertDataByText(con);
            //InsertDataByProcedure(con);
            //SelectSingleValue(con);
            SelectMultiValue(con);
            //SelectwithMARS(con);
            //InsertWithRollback(con);
        }

  
        static void Connect(SqlConnection con)
        {
           

            try
            {
                con.Open();
                Console.WriteLine("Connect Succes");
               
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        static void InsertDataByText(SqlConnection con)
        {
      

            try
            {
                con.Open();
                Console.WriteLine("Connect Success");

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "insert into Employees values(@empNo,@empName,@basic,@deptNo)";
                cmd.Parameters.AddWithValue("@empNo", 4);
                cmd.Parameters.AddWithValue("@empName", "Abhishek");
                cmd.Parameters.AddWithValue("@basic", 65000);
                cmd.Parameters.AddWithValue("@deptNo", 20);

                cmd.ExecuteNonQuery();
            }catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }

        static void InsertDataByProcedure(SqlConnection con)
        {

            try
            {
                con.Open();
                Console.WriteLine("Connect Success");

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.CommandText = "InsertDepartment";
                cmd.Parameters.AddWithValue("@deptNo", 30);
                cmd.Parameters.AddWithValue("@deptName", "Support");

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }

        static void SelectSingleValue(SqlConnection con)
        {


            try
            {
                con.Open();
                Console.WriteLine("Connect Success");

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "select count(*) from Departments";
                object retval = cmd.ExecuteScalar();

                Console.WriteLine(retval);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }

        static void SelectMultiValue(SqlConnection con)
        {

            try
            {
                con.Open();
                Console.WriteLine("Connect Success");

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "select * from Employees";
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    Console.WriteLine(dr.HasRows);
                    while (dr.Read())
                    {
                        //Console.WriteLine(dr[0]);
                        //Console.WriteLine(dr[1]);
                      
                        //Console.WriteLine(dr["deptNo"]);
                        Console.WriteLine(dr["empName"]);

                        Console.WriteLine(dr["deptNo"]);
                    }
                }
                else
                {
                    Console.WriteLine("No Data");
                }
            

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }

        static void SelectwithMARS(SqlConnection con)
        {

            try
            {
                con.Open();
                Console.WriteLine("Connect Success");

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                SqlCommand cmd2 = new SqlCommand();
                cmd2.Connection = con;

                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "select * from Departments";
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    cmd2.CommandText = "select * from Employees";
                    SqlDataReader drEmp = cmd2.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr["deptNo"].Equals(20))
                        {
                            while (drEmp.Read())
                            {

                                if (dr["deptNo"].Equals(drEmp["deptNo"]))
                                {
                                    Console.WriteLine(drEmp["empNo"]);
                                    Console.WriteLine(drEmp["empName"]);
                                }

                            }
                        }
                      
                    }
                 
                }
                else
                {
                    Console.WriteLine("No Data");
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }

        static void InsertWithRollback(SqlConnection con)
        {

            try
            {
                
                con.Open();
                SqlTransaction t = con.BeginTransaction();
                Console.WriteLine("Connect Success");

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.Transaction = t;
                SqlCommand cmd2 = new SqlCommand();
                cmd2.Connection = con;
                cmd2.Transaction = t;

                cmd.CommandType = System.Data.CommandType.Text;
                cmd2.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "insert into Departments values(@deptNo,@deptName)";
                cmd.Parameters.AddWithValue("deptNo", 40);
                cmd.Parameters.AddWithValue("deptName", "Testing");
                cmd2.CommandText = "insert into Employees values(@empNo,@empName,@basic,@deptNo)";
                cmd2.Parameters.AddWithValue("empNo", 5);
                cmd2.Parameters.AddWithValue("empName", "Archit");
                cmd2.Parameters.AddWithValue("basic", 5200);
                cmd2.Parameters.AddWithValue("deptNo", 30);

                try
                {
                    cmd.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    t.Commit();
                }
                catch (Exception ex) {
                    Console.WriteLine("Fail");
                    t.Rollback();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }




    }

   
}
