﻿namespace Events
{
    //public delegate void Del1();
    internal class Program
    {
        static void Main(string[] args)
        {
            Predicate<int> objDel = ShowAndy;
            objDel += ShowMukul;
            Console.WriteLine(objDel(23));

        }

        static bool ShowMukul(int age)
        {
            return age % 2 == 0;
        }

        static bool ShowAndy(int age)
        {
            return (age + 1) % 2 == 0;
        }
    }
}
