﻿namespace Inheritence
{
    internal class Program
    {
      
        public abstract class Employee
        {
            private static int count = 1;
            private string name;
            private int empNo;
            private short deptNo;
            private protected decimal basic;


            public Employee(string Name,short DeptNo,decimal Basic)
            {
                this.Name = Name;
                this.DeptNo = DeptNo;
                this.Basic = Basic;
                this.empNo = count++;
            }

            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    if(value != "")
                    {
                        name = value;
                    }
                    else
                    {
                        Console.WriteLine("Name Should not be blank");
                    }
                  
                }
            }

            public short DeptNo
            {
                get
                {
                    return deptNo;
                }
                set
                {

                    if(value > 0)
                    {
                        deptNo = value;
                    }
                    
                    else
                    {
                        Console.WriteLine("less than 0");
                    }
                }
            }

            public abstract decimal Basic
            {
                get;
                set;
            }

            public abstract decimal CalcNetSalary();

            public override string ToString()
            { 
                return ("Name " + Name + " EmpNo " + empNo + " DeptNo " + DeptNo +" Basic " + Basic); 
            }


        }


        public class Manager : Employee
        {
            private string designation;
          

            public Manager(string designation, string Name, short DeptNo, decimal Basic) : base( Name,  DeptNo, Basic)
            {
                Designation = designation;
            }

            public string Designation
            {
                get
                {
                    return designation;
                }
                set
                {
                    designation = value;
                }
            }

            public override decimal CalcNetSalary()
            {
                return Basic * 12;
            }

            public override string ToString()
            {
                return (base.ToString() + " " + Designation );
            }

            public override decimal Basic {
                get
                {
                    return  basic;
                }
                set { 
                    basic = value;
                }
            }

        }

        public class GeneralManager : Manager
        {
            private string perks;

            public GeneralManager(string perks , string designation, string Name, short DeptNo, decimal Basic) : base( designation,  Name,  DeptNo,  Basic)
            {
                Perks = perks;
            }

            public string Perks
            {
                get
                {
                    return perks;
                }
                set
                {
                    perks = value;
                }
            }

            public override decimal CalcNetSalary()
            {
                return base.Basic * 12;
            }

            public override string ToString()
            {
                return (base.ToString() + " " + Perks);
            }
            public override decimal Basic
            {
                get
                {
                    return basic;
                }
                set
                {
                    basic = value;
                }
            }

        }

        public class CEO : Employee
        {
            

            public CEO( string Name, short DeptNo, decimal Basic) : base( Name, DeptNo, Basic)
            {
               
            }

            public override sealed decimal CalcNetSalary()
            {
                return Basic * 12;
            }

            public override string ToString()
            {
                return base.ToString();
            }
            public override decimal Basic
            {
                get
                {
                    return basic;
                }
                set
                {
                    basic = value;
                }
            }
        }

        static void Main(string[] args)
        {
            Employee e1 = new Manager("CTO", "Mukul", 10, 2500);
            Employee e3 = new CEO("Abhishek", 11, 2600);
            Employee e2 = new GeneralManager("House", "CFO", "Nakul", 12, 8500);
      
            Console.WriteLine(e1);
            Console.WriteLine(e3);
            Console.WriteLine(e2);

          
        }
    }
}
